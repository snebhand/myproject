<?php
namespace Drupal\drush_command_example\Commands;
use Drush\Commands\DrushCommands;
use Drupal\Component\Serialization\Json;
use Drupal\node\Entity\Node;
/**
 * Drush command file.
 */
class CustomCommands extends DrushCommands {

  /**
   * A custom Drush command to displays the given text.
   * 
   * @command drush-command-example:print-me
   * @param $text Argument with text to be printed
   * @option uppercase Uppercase the text
   * @aliases ttndrush,tthndrush-print-me
   */
  public function printMe($text = 'Hello world!', $options = ['uppercase' => FALSE]) {
    if ($options['uppercase']) {
      $text = strtoupper($text);
    }
    $this->output()->writeln($text);
    $url="https://jsonplaceholder.typicode.com/photos";
    $response = \Drupal::httpClient()->request('GET', $url);
    $data = $response->getBody()->getContents();
    $decoded = json_decode($data);
    foreach($decoded as $key => $value){
               
      $albumId = $value->albumId;
          $id = $value->id;
          $title = $value->title;
          $url = $value->url;
          $thumbnailUrl = $value->thumbnailUrl;
   
       
    $node = Node::create([
      'type' => 'drush_data',
      'title' => $title,
      'field_id' => $id,
      'field_albumid' => $albumId,
      'field_url' => $url,
      'field_thumbnailurl' => $thumbnailUrl
      ]);
    $node->save();


}
  $this->output()->writeln("data impoted successfully");
  
  }
  

} 